# Documentation Digester Chatbot

Project 4 starter structure.

## Backend
FastAPI + LangChain + Sentence-Transformers + Chroma/FAISS.

## Frontend
React + TypeScript + Vite.

## Data Pipeline
Raw documentation -> cleaning -> semantic chunking -> embeddings -> vector database -> retrieval -> conversational response.

All implementation files are intentionally blank so the project can be built from the assignment requirements.
